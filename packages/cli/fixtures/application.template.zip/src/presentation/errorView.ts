import * as Kernel from '@avanzu/kernel'

@Kernel.ErrorPresenter()
export class ErrorView extends Kernel.ErrorView {

}
