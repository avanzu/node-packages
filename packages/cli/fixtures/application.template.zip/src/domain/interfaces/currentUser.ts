export interface CurrentUser {
    getUsername() : string
}